﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Class1
    {
        public DateTime data
        {
            get; set;
        }

        public Class1(int year, int month, int day)
        {
            DateTime date = new DateTime(year, month, day);
        }
        
        public DateTime NextDay()
        {
            DateTime next = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day + 1);
            return next;
        }

        public DateTime PreviousDay()
        {
            DateTime previous = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day - 1);
            return previous;
        }

        public int EndOfMonth()
        {
            int dim = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);
            int days = DateTime.Now.Day;
            return dim - days;
        }

        public bool LeapYear
        {
            get { return DateTime.IsLeapYear(data.Year); }
        }
    }
}
