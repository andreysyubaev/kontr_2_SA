﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=start=");
            Console.WriteLine();
            try
            {
                Console.Write("год (xxxx): ");
                int year = int.Parse(Console.ReadLine());
                if (!Year(year))
                {
                    Console.WriteLine("error");
                    Console.ReadKey();
                    return;
                }

                Console.Write("месяц: ");
                int month = int.Parse(Console.ReadLine());
                if (!Month(month))
                {
                    Console.WriteLine("error");
                    Console.ReadKey();
                    return;
                }

                Console.Write("день: ");
                int day = int.Parse(Console.ReadLine());
                if (!Day(day))
                {
                    Console.WriteLine("error");
                    Console.ReadKey();
                    return;
                }

                Class1 d = new Class1(year, month, day);
                Console.WriteLine("заданная дата: " + Class1.d);
                Console.WriteLine("следующий день: " + d.NextDay());
                Console.WriteLine("предыдущий день: " + d.PreviousDay());
                Console.WriteLine("дней до конца месяца: " + d.EndOfMonth());
                Console.WriteLine("является ли заданный год високосным?: " + d.LeapYear);

                Console.WriteLine();
                Console.WriteLine("=end=");
                Console.Read();

            }
            catch
            {
                Console.WriteLine("error");
                return;
            }
            Console.Read();
        }

        static bool Year(int text)
        {
            string pr = "xxxx";
            if (Convert.ToString(text).Length < pr.Length || Convert.ToString(text).Length > pr.Length || text < 1)
                return false;
            else
                return true;
        }

        static bool Month(int text)
        {
            string pr1 = "xx";
            string pr2 = "x";
            if (Convert.ToString(text).Length < pr2.Length || Convert.ToString(text).Length > pr1.Length || text < 1 || text > 12)
                return false;
            else
                return true;
        }

        static bool Day(int text)
        {
            string pr1 = "xx";
            string pr2 = "x";
            if (Convert.ToString(text).Length < pr2.Length || Convert.ToString(text).Length > pr1.Length || text < 1 || text > DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month))
                return false;
            else
                return true;
        }
    }
}
